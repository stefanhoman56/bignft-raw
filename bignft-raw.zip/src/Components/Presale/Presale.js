import React from 'react'
import PresaleCard from './PresaleCard'
import Footer from "../Footer/Footer";

function Presale() {
  return (
    <section className='main'>
        <div className='container'>
            <PresaleCard/>

        </div>
        <Footer/>
    </section>
  )
}

export default Presale