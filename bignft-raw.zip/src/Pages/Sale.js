import React from 'react'
import Navbar from '../Components/Navbar/Navbar'
import Presale from '../Components/Presale/Presale'

function Sale() {
  return (
    <>
    <Navbar/>
    <Presale/>
    
    </>
  )
}

export default Sale